import java.util.*;

class WordOccurrence implements Comparable<WordOccurrence>{
	String word;
	Integer count;
	public WordOccurrence(String wd,int count){
		this.word = word;
		this.count = count;
	}
	public int compareTo(WordOccurrence o){
		return o.count.compareTo(count);
	}
}